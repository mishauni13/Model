package util;

import java.util.LinkedList;
import java.util.Map;

import model.Edge;
import model.Graph;
import model.Vertex;

/**
 * Class contains some methods for graph processing.
 */
public class GraphUtils {
    
    /**
     * Prints graph relations to console.
     *
     * @param graph - graph to print.
     * @param <T>   - graph vertices type.
     */
    public static <T> void printGraph(Graph<T> graph) {
        Map<Vertex<T>, LinkedList<Edge<T>>> vertices = graph.getData();
        
        for (Vertex<T> vertex : vertices.keySet()) {
            LinkedList<Edge<T>> edges = vertices.get(vertex);
            if (edges.isEmpty()) {
                continue;
            }
            System.out.println("Relations list of vertex " + vertex.toString());
            for (Edge<T> edge : edges) {
                System.out.print(edge.toString() + "\n");
            }
        }
    }
    
    //TODO: some useful algorithms and methods.
}
