package model;

/**
 * Class represents graph edge connecting two vertices.
 * {@link Vertex}.
 *
 * @param <T> - value type.
 */
public class Edge<T> {
    
    /**
     * Parent vertex.
     */
    private final Vertex<T> parent;
    
    /**
     * Child vertex.
     */
    private final Vertex<T> child;
    
    /**
     * Edge weight.
     */
    private Float weight;
    
    /**
     * Indicates whatever this edge is weighted.
     */
    private boolean isWeighted;
    
    /**
     * Indicates that this edge has direction.
     */
    private final boolean isDirected;
    
    /**
     * Instantiates a new Edge.
     *
     * @param parent     the parent
     * @param child      the child
     * @param isDirected the is directed
     */
    public Edge(
            Vertex<T> parent,
            Vertex<T> child,
            boolean isDirected
    ) {
        this.parent = parent;
        this.child = child;
        this.isDirected = isDirected;
        
        this.isWeighted = false;
        this.weight = 1.0f;
    }
    
    /**
     * Instantiates a new Edge.
     *
     * @param parent     the parent
     * @param child      the child
     * @param weight     the weight
     * @param isDirected the is directed
     */
    public Edge(
            Vertex<T> parent,
            Vertex<T> child,
            Float weight,
            boolean isDirected
    ) {
        this.parent = parent;
        this.child = child;
        this.weight = weight;
        this.isDirected = isDirected;
        
        this.isWeighted = true;
    }
    
    /**
     * Add weight.
     *
     * @param weight the weight
     */
    public void addWeight(Float weight) {
        if (!isWeighted) {
            this.isWeighted = true;
        }
        
        this.weight = weight;
    }
    
    /**
     * Checks if this edge parent or child is equal to specified vertex.
     *
     * @param vertex - vertex to check.
     * @return true if child or parent is equal to specified vertex.
     */
    public boolean contains(Vertex<T> vertex) {
        return this.child.equals(vertex) || this.parent.equals(vertex);
    }
    
    /**
     * Gets parent.
     *
     * @return the parent
     */
    @SuppressWarnings ("WeakerAccess")
    public Vertex<T> getParent() {
        return parent;
    }
    
    /**
     * Gets child.
     *
     * @return the child
     */
    public Vertex<T> getChild() {
        return child;
    }
    
    @Override
    public String toString() {
        String r = "(%s, %s)";
        
        String relation = isDirected ? "(%s -> %s)" : "(%s - %s)";
        relation = String.format(relation, parent.toString(), child.toString());
        
        if (isWeighted) {
            r = String.format(r, relation, weight);
        } else {
            r = relation;
        }
        
        return r;
    }
    
    /**
     * Gets edge weight.
     * @return the weight.
     */
    public Float getWeight() {
        return this.weight;
    }
}
