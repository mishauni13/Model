package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Class represents graph.
 *
 * @param <T> - vertices type.
 */
public class Graph<T> {
    
    /**
     * Contains true if graph is directed.
     */
    private final boolean isDirected;
    
    /**
     * Contains root graph vertex.
     * Or first added if not specified.
     */
    @SuppressWarnings ("WeakerAccess")
    protected Vertex<T> rootVertex;
    
    /**
     * Contains all vertices and
     * {@link LinkedList} with all relations.
     */
    private final Map<Vertex<T>, LinkedList<Edge<T>>> vertices;
    
    /**
     * Instantiates a new Graph.
     *
     * @param isDirected the is directed boolean.
     */
    public Graph(boolean isDirected) {
        this.isDirected = isDirected;
        this.vertices = new HashMap<>();
    }
    
    /**
     * Creates graph from specified root vertex.
     *
     * @param root - root vertex of new graph.
     * @param <T>  - graph vertices type.
     * @return new graph.
     */
    public static <T> Graph<T> createGraphFromRootVertexRelations(Vertex<T> root) {
        Graph<T>      graph = new Graph<>(true);
        List<Edge<T>> edges = new ArrayList<>(root.getRelatedEdges());
        for (var edge :
                edges) {
            graph.addEdge(edge.getParent(), edge.getChild());
            graph.addEdges(edge.getParent().getRelatedEdges(), edge.getParent());
        }
        
        return graph;
    }
    
    /**
     * Creates graph from specified root vertex object.
     *
     * @param root - root element.
     * @param <T>  - graph elements type.
     * @return new graph.
     */
    public static <T> Graph<T> createGraphFromRootVertexRelations(T root) {
        Vertex<T> rootVertex = new Vertex<>(root);
        
        return createGraphFromRootVertexRelations(rootVertex);
    }
    
    /**
     * Clears all vertices.
     */
    public void clear() {
        this.vertices.clear();
        this.rootVertex = null;
    }
    
    /**
     * Gets root vertex.
     *
     * @return the root vertex;
     */
    public Vertex<T> getRootVertex() {
        return this.rootVertex;
    }
    
    /**
     * Gets vertex and relations.
     *
     * @return vertex and relations.
     */
    public Map<Vertex<T>, LinkedList<Edge<T>>> getData() {
        return this.vertices;
    }
    
    /**
     * Removes vertex.
     *
     * @param vertex the vertex to remove.
     */
    public void removeVertex(
            Vertex<T> vertex
    ) {
        Map<Vertex<T>, LinkedList<Edge<T>>> vertices = this.vertices;
        
        vertices.values().forEach(e -> {
            for (Edge<T> edge :
                    e) {
                if (edge.contains(vertex)) {
                    e.remove(edge);
                }
            }
        });
        vertices.remove(vertex);
    }
    
    /**
     * Adds edge only if parent vertex exists.
     * Returns true if created with success.
     *
     * @param parent - parent vertex.
     * @param child  - child vertex.
     * @return true if there wasn't errors.
     */
    @SuppressWarnings ("WeakerAccess")
    public boolean addEdgeIfParentExists(
            Vertex<T> parent,
            Vertex<T> child
    ) {
        if (this.contains(parent)) {
            this.addEdge(parent, child);
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * Checks if current graph contains specified vertex.
     *
     * @param vertex - vertex to find.
     * @return true if there is the same vertex in this graph.
     */
    public boolean contains(Vertex<T> vertex) {
        return this.vertices.containsKey(vertex);
    }
    
    /**
     * Adds edge.
     *
     * @param parent the parent
     * @param child  the child
     */
    @SuppressWarnings ("WeakerAccess")
    public void addEdge(
            Vertex<T> parent,
            Vertex<T> child
    ) {
        Map<Vertex<T>, LinkedList<Edge<T>>> vertices = this.vertices;
        
        if (!vertices.containsKey(parent)) {
            this.addVertex(parent);
        }
        if (!vertices.containsKey(child)) {
            this.addVertex(child);
        }
        
        Edge<T> edge = new Edge<>(parent, child, isDirected);
        
        vertices.get(parent).add(edge);
        findVertex(parent.getStoredObject()).addEdge(edge);
        if (!isDirected) {
            vertices.get(child).add(edge);
            findVertex(child.getStoredObject()).addEdge(edge);
        }
    }
    
    /**
     * Adds new vertex to graph.
     *
     * @param vertex - vertex to add.
     */
    @SuppressWarnings ("WeakerAccess")
    public void addVertex(
            Vertex<T> vertex
    ) {
        if (rootVertex == null) {
            rootVertex = vertex;
        }
        this.vertices.putIfAbsent(vertex, new LinkedList<>());
    }
    
    public Vertex<T> findVertex(T obj) {
        
        ArrayList<Vertex<T>> keys = getVertices();
        
        for (Vertex<T> v :
                keys) {
            if (v.getStoredObject().equals(obj)) {
                return v;
            }
        }
        return null;
    }
    
    /**
     * Gets vertices.
     *
     * @return all vertices {@link ArrayList}.
     */
    public ArrayList<Vertex<T>> getVertices() {
        return new ArrayList<>(this.vertices.keySet());
    }
    
    public Edge<T> getEdgeBetweenValues(
            T value1,
            T value2
    ) {
        Vertex<T> vertex2 = findVertex(value2);
        Vertex<T> vertex1 = findVertex(value1);
        if (vertex1 != null && vertex2 != null) {
            for (LinkedList<Edge<T>> edgesList :
                    vertices.values()) {
                for (Edge<T> edge :
                        edgesList) {
                    if (edge.contains(vertex1) && edge.contains(vertex2)) {
                        return edge;
                    }
                }
            }
            return null;
        } else {
            return null;
        }
    }
    
    /**
     * Adds graph to this graph.
     *
     * @param parent - node to connect with.
     * @param graph  - graph to add.
     * @return new graph.
     */
    public boolean addGraph(
            Vertex<T> parent,
            Graph<T> graph
    ) {
        if (graph.isDirected) {
            Vertex<T> graphRootVertex = graph.getRootVertex();
            this.addEdge(parent, graphRootVertex);
            
            final LinkedList<Edge<T>> relatedToRoot = new LinkedList<>(
                    graphRootVertex.getRelatedEdges());
            
            for (Edge<T> e :
                    relatedToRoot) {
                Vertex<T> ec = e.getChild();
                this.addEdge(graphRootVertex, ec);
                this.addEdges(ec.getRelatedEdges(), ec);
            }
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * Adds edges.
     *
     * @param edges  edges to add.
     * @param parent parent vertex.
     */
    @SuppressWarnings ("WeakerAccess")
    public void addEdges(
            List<Edge<T>> edges,
            Vertex<T> parent
    ) {
        for (Edge<T> e :
                edges) {
            Vertex<T> ec = e.getChild();
            if (!this.contains(ec)) {
                this.addEdge(parent, ec);
                this.addEdges(ec.getRelatedEdges(), ec);
            }
        }
    }
    
    /**
     * Add edge.
     *
     * @param parent the parent
     * @param child  the child
     * @param weight the weight
     */
    public void addEdge(
            Vertex<T> parent,
            Vertex<T> child,
            float weight
    ) {
        Map<Vertex<T>, LinkedList<Edge<T>>> vertices = this.vertices;
        
        if (!vertices.containsKey(parent)) {
            this.addVertex(parent);
        }
        if (!vertices.containsKey(child)) {
            this.addVertex(child);
        }
        
        Edge<T> edge = new Edge<>(parent, child, weight, isDirected);
        
        parent.addEdge(edge);
        vertices.get(parent).add(edge);
        if (!isDirected) {
            child.addEdge(edge);
            vertices.get(child).add(edge);
        }
    }
    
    /**
     * Remove edge.
     *
     * @param vertex1 the vertex 1
     * @param vertex2 the vertex 2
     */
    public void removeEdge(
            Vertex<T> vertex1,
            Vertex<T> vertex2
    ) {
        Map<Vertex<T>, LinkedList<Edge<T>>> vertices = this.vertices;
        
        var eV1 = vertices.get(vertex1);
        var eV2 = vertices.get(vertex2);
        if (eV1 != null) {
            eV1.forEach(e -> {
                if (e.contains(vertex2)) {
                    eV1.remove(e);
                }
            });
        }
        if (eV2 != null) {
            eV2.forEach(e -> {
                if (e.contains(vertex1)) {
                    eV2.remove(e);
                }
            });
        }
    }
    
    public List<Vertex<? extends T>> getVerticesByType(Class<? extends T> type) {
        List<Vertex<? extends T>> tests = new ArrayList<>();
    
        for (Vertex<? extends T> v :
                this.getVertices()) {
            if (type.isInstance(v.getStoredObject())) {
                tests.add(v);
            }
        }
    
        return tests;
    }
}
