package model;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * Class represents graph vertex.
 * Vertex contains boxedObject.
 *
 * @param <T> vertex boxedObject type.
 */
public class Vertex<T> {
    
    /**
     * Unique identifier.f
     */
    private final String              id;
    private       Float               value1       = 0.0f;
    private       Float               value2       = 0.0f;
    private       Float               value3       = 0.0f;
    /**
     * Value that stored in vertex.
     */
    private       T                   boxedObject;
    /**
     * List of related to this vertex edges.
     */
    private       LinkedList<Edge<T>> relatedEdges = new LinkedList<>();
    
    //Initializes id.
    {
        this.id = UUID.randomUUID().toString();
    }
    
    /**
     * Instantiates a new Vertex.
     *
     * @param boxedObject the boxedObject object.
     */
    public Vertex(T boxedObject) {
        this.boxedObject = boxedObject;
    }
    
    /**
     * Instantiates a new Vertex.
     *
     * @param boxedObject the boxedObject object.
     * @param value1      - value1.
     */
    public Vertex(
            T boxedObject,
            Float value1,
            Float value2,
            Float value3
    ) {
        this.boxedObject = boxedObject;
        this.value1 = value1;
        this.value2 = value2;
        this.value3 = value3;
    }
    
    /**
     * Instantiates a new Vertex.
     *
     * @param boxedObject the boxedObject
     * @param edges       the edges
     */
    public Vertex(
            T boxedObject,
            Edge... edges
    ) {
        this.boxedObject = boxedObject;
        
        //noinspection unchecked
        List<Edge<T>> edgeList = Arrays.asList(edges);
        this.relatedEdges = new LinkedList<>(edgeList);
    }
    
    /**
     * Gets vertex value1.
     *
     * @return the value1.
     */
    public Float[] getValue() {
        return new Float[]{this.value1, this.value2, this.value3};
    }
    
    public void setValue(
            Float value1,
            Float value2,
            Float value3
    ) {
        this.value1 = value1;
        this.value2 = value2;
        this.value3 = value3;
    }
    
    /**
     * Adds related edge.
     *
     * @param edge the edge to add.
     */
    @SuppressWarnings ("WeakerAccess")
    public void addEdge(Edge<T> edge) {
        this.relatedEdges.add(edge);
    }
    
    /**
     * Gets related edges.
     *
     * @return the related edges.
     */
    public LinkedList<Edge<T>> getRelatedEdges() {
        return relatedEdges;
    }
    
    /**
     * Gets Vertex id.
     *
     * @return - the id.
     */
    private String getId() {
        return this.id;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(boxedObject);
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Vertex<?> vertex = (Vertex<?>) o;
        return Objects.equals(boxedObject, vertex.boxedObject);
    }
    
    @Override
    public String toString() {
        return boxedObject.toString();
    }
    
    /**
     * Gets object stored inside vertex.
     *
     * @return - object.
     */
    public T getStoredObject() {
        return this.boxedObject;
    }
    
    /**
     * Sets boxedObject object.
     *
     * @param boxedObject the boxedObject object to store.
     */
    public void setBoxedObject(T boxedObject) {
        this.boxedObject = boxedObject;
    }
}
