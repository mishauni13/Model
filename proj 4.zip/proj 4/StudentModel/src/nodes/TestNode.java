package nodes;

import java.util.ArrayList;
import java.util.List;

/**
 * Node represents test.
 * {@link Node}.
 */
public class TestNode
        extends Node {
    
    /**
     * Test name.
     */
    private final String name;
    
    /**
     * Questions.
     */
    private final List<QuestionNode> questions = new ArrayList<>();
    
    {
        this.type = Type.Test;
    }
    
    /**
     * Initializes new test.
     *
     * @param name      - test name.
     * @param questions - questions.
     */
    public TestNode(
            String name,
            QuestionNode... questions
    ) {
        super(name);
        this.name = name;
        this.addQuestions(questions);
    }
    
    /**
     * Adds questions.
     *
     * @param questions - questions to add.
     */
    public void addQuestions(QuestionNode... questions) {
        for (QuestionNode q :
                questions) {
            if (!this.questions.contains(q)) {
                this.questions.add(q);
            }
        }
    }
    
    /**
     * Initializes new Test without questions.
     *
     * @param name - test name.
     */
    public TestNode(String name) {
        super(name);
        this.name = name;
    }
    
    @Override
    public List<QuestionNode> getChildNodes() {
        return questions;
    }
    
    @Override
    public String toString() {
        return "t-" + super.toString();
    }
}
