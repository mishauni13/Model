package nodes;

import java.util.List;
import java.util.UUID;

/**
 * Class represents single element in {@link model.CourseGraph}
 * {@link CompetenceNode}
 * {@link TopicNode}
 * {@link SubtopicNode}
 * {@link TestNode}
 * {@link QuestionNode}
 */
public abstract class Node {
    
    /**
     * Node name identifier.
     */
    private final String name;
    /**
     * Node auto-generated id.
     */
    @SuppressWarnings ("FieldCanBeLocal")
    private final String id;
    
    @SuppressWarnings ("WeakerAccess")
    protected Float value1 = 0.0f;
    @SuppressWarnings ("WeakerAccess")
    protected Float value2 = 0.0f;
    @SuppressWarnings ("WeakerAccess")
    protected Float value3 = 0.0f;
    /**
     * Node {@link Type}.
     */
    protected Type  type;
    
    Node(String name) {
        this.name = name;
        this.id = UUID.randomUUID().toString();
    }
    
    public Float getValue2() {
        if (this.value2 == 0.0f) {
            this.calculateValues();
        }
        return this.value2;
    }
    
    public Float getValue3() {
        if (this.value3 == 0.0f) {
            this.calculateValues();
        }
        return this.value3;
    }
    
    /**
     * Calculates node value1.
     */
    @SuppressWarnings ("WeakerAccess")
    public void calculateValues() {
        List<? extends Node> childNodes = getChildNodes();
        if (childNodes != null && !childNodes.isEmpty()) {
            
            Float sum1 = 0.0f;
            Float sum2 = 0.0f;
            Float sum3 = 0.0f;
            
            for (Node n :
                    childNodes) {
                sum1 += n.getValue1();
                sum2 += n.getValue2();
                sum3 += n.getValue3();
            }
            
            this.value1 = sum1 / childNodes.size();
            this.value2 = sum2 / childNodes.size();
            this.value3 = sum3 / childNodes.size();
        } else {
            this.value1 = 0.0f;
            this.value2 = 0.0f;
            this.value3 = 0.0f;
        }
    }
    
    /**
     * Gets node value1 or recalculates it if 0.
     *
     * @return node value1.
     */
    public Float getValue1() {
        if (this.value1 == 0.0f) {
            this.calculateValues();
        }
        return this.value1;
    }
    
    /**
     * Child nodes.
     *
     * @return gets child nodes.
     */
    public abstract List<? extends Node> getChildNodes();
    
    /**
     * Gets node type.
     *
     * @return current node type.
     */
    public Type getType() {
        return this.type;
    }
    
    @Override
    public String toString() {
        return this.name;
    }
    
    /**
     * Enum containing all possible node types
     * in {@link model.CourseGraph} model.
     */
    public enum Type {
        /**
         * Competence node type.
         */
        Competence,
        
        /**
         * Topic node type.
         */
        Topic,
        
        /**
         * Subtopic node type.
         */
        Subtopic,
        
        /**
         * Test node type.
         */
        Test,
        
        /**
         * Question node type.
         */
        Question
    }
}
