package nodes;

import java.util.ArrayList;
import java.util.List;

/**
 * Node represents topic.
 * {@link Node}.
 */
public class TopicNode
        extends Node {
    
    /**
     * List of subtopics for this topic node.
     */
    private final List<SubtopicNode> subtopics = new ArrayList<>();
    
    /**
     * Topic name.
     */
    private String topicName;
    
    //Node type initializer.
    {
        this.type = Type.Topic;
    }
    
    /**
     * Instantiates a new Topic node.
     *
     * @param name - topic name.
     */
    public TopicNode(String name) {
        super(name);
        this.topicName = name;
    }
    
    /**
     * Initialises new Topic.
     *
     * @param name      - topic name.
     * @param subtopics - subtopics.
     */
    public TopicNode(
            String name,
            SubtopicNode... subtopics
    ) {
        super(name);
        this.topicName = name;
        this.addSubtopics(subtopics);
    }
    
    /**
     * Adds subtopics.
     *
     * @param subtopics - subtopics to add.
     */
    public void addSubtopics(SubtopicNode... subtopics) {
        for (SubtopicNode s :
                subtopics) {
            if (!this.subtopics.contains(s)) {
                this.subtopics.add(s);
            }
        }
    }
    
    /**
     * Gets topic name.
     *
     * @return topic name.
     */
    public String getTopicName() {
        return topicName;
    }
    
    /**
     * Gets subtopics.
     *
     * @return the subtopics.
     */
    @Override
    public List<SubtopicNode> getChildNodes() {
        return subtopics;
    }
    
    @Override
    public String toString() {
        return "T-" + super.toString();
    }
}
