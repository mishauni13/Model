package nodes;

import java.util.List;

/**
 * Node represents question element in course graph.
 * {@link Node}.
 * {@link model.CourseGraph}.
 */
public class QuestionNode
        extends Node {
    
    /**
     * Question text.
     */
    private final String text;
    /**
     * Answers.
     */
    private final Answers answers;
    
    {
        this.type = Type.Question;
        this.value1 = 0.0f;
    }
    
    /**
     * Initializes question.
     *
     * @param name    - question node name.
     * @param text    - question text.
     * @param answers - answers.
     */
    public QuestionNode(
            String name,
            String text,
            Answers answers
    ) {
        super(name);
        this.text = text;
        this.answers = answers;
    }
    
    /**
     * Sets question value1.
     * 1 if answer was right.
     *
     * @param value1 - value1 to set.
     * @param value2 - value2 to set.
     * @param value3 - value3 to set.
     */
    public void setValue(
            Float value1,
            Float value2,
            Float value3
    ) {
        if (value1 >= 0 && value1 <= 1 && value2 >= 0 && value2 <= 1 && value3 >= 0 &&
            value3 <= 1 && value1 + value2 + value3 == 1) {
            this.value1 = value1;
            this.value2 = value2;
            this.value3 = value3;
        } else {
            throw new IllegalArgumentException("Node value1 may be in range of 0-1!");
        }
    }
    
    @Override
    public void calculateValues() {
        return;
    }
    
    /**
     * Question node contains no child elements.
     *
     * @return null.
     */
    @Override
    public List<? extends Node> getChildNodes() {
        return null;
    }
    
    @Override
    public String toString() {
        return "Q-" + super.toString();
    }
    
    /**
     * Gets text.
     *
     * @return the text.
     */
    public String getText() {
        return this.text;
    }
    
    /**
     * Gets answers.
     *
     * @return the answers.
     */
    public Answers getAnswers() {
        return this.answers;
    }
    
    /**
     * Class represents answers.
     */
    public static class Answers {
        
        /**
         * List of wrong answers.
         */
        @SuppressWarnings ("FieldCanBeLocal")
        private final List<String> wrongAnswers;
        
        /**
         * Right answer.
         */
        @SuppressWarnings ("FieldCanBeLocal")
        private final String rightAnswer;
        
        /**
         * Initializes new answers.
         *
         * @param wrongAnswers - wrong answers list.
         * @param rightAnswer  - right answer.
         */
        public Answers(
                List<String> wrongAnswers,
                String rightAnswer
        ) {
            this.wrongAnswers = wrongAnswers;
            this.rightAnswer = rightAnswer;
        }
        
        //TODO: answer validation if needed.
    }
}
