package nodes;

import java.util.ArrayList;
import java.util.List;

/**
 * Node represents subtopic.
 * {@link Node}.
 */
public class SubtopicNode
        extends Node {
    
    /**
     * Subtopic name.
     */
    private final String subtopicName;
    
    /**
     * Tests.
     */
    private final List<TestNode> tests = new ArrayList<>();
    
    {
        this.type = Type.Subtopic;
    }
    
    /**
     * Instantiates a new Subtopic node.
     *
     * @param name the name
     */
    public SubtopicNode(String name) {
        super(name);
        this.subtopicName = name;
    }
    
    /**
     * Initializes new subtopic.
     *
     * @param name  - sub-topic name.
     * @param tests - tests.
     */
    public SubtopicNode(
            String name,
            TestNode... tests
    ) {
        super(name);
        this.subtopicName = name;
        addTests(tests);
    }
    
    /**
     * Add test.
     *
     * @param tests the test
     */
    public void addTests(TestNode... tests) {
        for (TestNode t :
                tests) {
            if (!this.tests.contains(t)) {
                this.tests.add(t);
            }
        }
    }
    
    /**
     * Gets tests.
     *
     * @return the tests
     */
    @Override
    public List<TestNode> getChildNodes() {
        return tests;
    }
    
    @Override
    public String toString() {
        return "s-" + super.toString();
    }
    
    /**
     * Gets subtopic name.
     *
     * @return the subtopic name
     */
    public String getSubtopicName() {
        return subtopicName;
    }
}
