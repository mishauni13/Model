package nodes;

import java.util.ArrayList;
import java.util.List;

/**
 * Node represents competence.
 * {@link Node}.
 */
public class CompetenceNode
        extends Node {
    
    /**
     * Competence name.
     */
    private final String competenceName;
    
    /**
     * Topics list.
     */
    private final List<TopicNode> topics = new ArrayList<>();
    
    //Node type initializer.
    {
        this.type = Type.Competence;
    }
    
    /**
     * Instantiates a new Competence node.
     *
     * @param name - competence name.
     */
    public CompetenceNode(String name) {
        super(name);
        competenceName = name;
    }
    
    /**
     * Initializes node with sub-nodes.
     *
     * @param name   - competence name.
     * @param topics - topic nodes.
     */
    public CompetenceNode(
            String name,
            TopicNode... topics
    ) {
        super(name);
        this.competenceName = name;
        this.addTopics(topics);
    }
    
    /**
     * Adds topics.
     *
     * @param topics the topics to add to this competence.
     */
    public void addTopics(TopicNode... topics) {
        for (TopicNode t :
                topics) {
            if (!this.topics.contains(t)) {
                this.topics.add(t);
            }
        }
    }
    
    /**
     * Gets competence name.
     *
     * @return the competence name.
     */
    public String getCompetenceName() {
        return competenceName;
    }
    
    /**
     * Gets topics.
     *
     * @return the topics.
     */
    @Override
    public List<TopicNode> getChildNodes() {
        return topics;
    }
    
    @Override
    public String toString() {
        return "C-" + super.toString();
    }
}
