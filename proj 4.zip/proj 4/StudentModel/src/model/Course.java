package model;

import java.util.Date;

/**
 * Class represents student course.
 */
public class Course {
    
    /**
     * Course name.
     */
    private final String name;
    
    /**
     * Course comments.
     */
    private final String description;
    
    /**
     * Author name.
     */
    private String authorName;
    
    /**
     * Course creation date.
     */
    private Date creationDate;
    
    /**
     * Course graph.
     */
    private CourseGraph courseGraph;
    
    /**
     * Instantiates a new Course.
     *
     * @param name         the name
     * @param description  the description
     * @param authorName   the authorName
     * @param creationDate the creation date
     */
    public Course(
            String name,
            String description,
            String authorName,
            Date creationDate
    ) {
        this.name = name;
        this.description = description;
        this.authorName = authorName;
        this.creationDate = creationDate;
        
        this.courseGraph = new CourseGraph(this.name);
    }
    
    /**
     * Instantiates a new Course.
     *
     * @param name        the name
     * @param description the description
     */
    public Course(
            String name,
            String description
    ) {
        this.name = name;
        this.description = description;
        
        this.courseGraph = new CourseGraph(this.name);
    }
    
    /**
     * Gets name.
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }
    
    /**
     * Gets description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }
    
    /**
     * Gets authorName.
     *
     * @return the authorName
     */
    public String getAuthorName() {
        return this.authorName;
    }
    
    /**
     * Gets creation date.
     *
     * @return the creation date
     */
    public Date getCreationDate() {
        return this.creationDate;
    }
    
    /**
     * Gets courseGraph.
     *
     * @return the courseGraph
     */
    public CourseGraph getCourseGraph() {
        return this.courseGraph;
    }
    
    /**
     * Sets the course graph.
     *
     * @param courseGraph - graph to set.
     */
    public void setCourseGraph(CourseGraph courseGraph) {
        this.courseGraph = courseGraph;
    }
}
