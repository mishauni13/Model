package model;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import nodes.CompetenceNode;
import nodes.Node;
import nodes.QuestionNode;
import nodes.SubtopicNode;
import nodes.TestNode;
import nodes.TopicNode;

/**
 * The type Course graph.
 */
public class CourseGraph
        extends Graph<Node> {
    
    private final CompetenceNode rootCompetenceNode;
    
    /**
     * Instantiates a new Course graph.
     *
     * @param courseName the course name
     */
    public CourseGraph(String courseName) {
        super(true);
        
        rootCompetenceNode = new CompetenceNode(courseName);
        rootVertex = new Vertex<>(rootCompetenceNode);
        this.addVertex(rootVertex);
    }
    
    /**
     * Instantiates a new Course graph.
     *
     * @param rootCompetenceNode the root competence node
     */
    public CourseGraph(
            CompetenceNode rootCompetenceNode
    ) {
        super(true);
        this.rootCompetenceNode = rootCompetenceNode;
        rootVertex = new Vertex<>(rootCompetenceNode);
        this.addVertex(rootVertex);
        
        recreateGraphFromRootVertexRelations(this.rootCompetenceNode);
    }
    
    public Float[] calculateVertexProbability(Node node) {
        syncVertexValuesWithNodes();
        Vertex<Node> vertex = findVertex(node);
        
        if (vertex != null) {
            float sum1 = 0.0f;
            float sum2 = 0.0f;
            float sum3 = 0.0f;
            
            LinkedList<Edge<Node>> relatedEdges = vertex.getRelatedEdges();
            
            for (Edge<Node> edge :
                    relatedEdges) {
                Float w = edge.getWeight();
                
                Node childNode = edge.getChild().getStoredObject();
                sum1 += childNode.getValue1() * w;
                sum2 += childNode.getValue2() * w;
                sum3 += childNode.getValue3() * w;
            }
            vertex.setValue(sum1 / relatedEdges.size(), sum2 / relatedEdges.size(),
                            sum3 / relatedEdges.size());
            return vertex.getValue();
        }
        
        return null;
    }
    
    private void syncVertexValuesWithNodes() {
        for (Vertex<Node> v :
                this.getVertices()) {
            Node storedObject = v.getStoredObject();
            v.setValue(storedObject.getValue1(), storedObject.getValue2(),
                       storedObject.getValue3());
        }
    }
    
    private void recreateGraphFromRootVertexRelations(CompetenceNode competenceNode) {
        List<TopicNode> topics = new ArrayList<>(competenceNode.getChildNodes());
        for (var topic :
                topics) {
            addTopic(topic);
            List<SubtopicNode> subtopics = new ArrayList<>(topic.getChildNodes());
            
            for (var subtopic :
                    subtopics) {
                addSubtopic(topic, subtopic);
                List<TestNode> tests = new ArrayList<>(subtopic.getChildNodes());
                
                for (var test :
                        tests) {
                    addTest(subtopic, test);
                    List<QuestionNode> questions = new ArrayList<>(test.getChildNodes());
                    
                    for (var question :
                            questions) {
                        addQuestion(test, question);
                    }
                }
            }
        }
    }
    
    /**
     * Add topic.
     *
     * @param topic the topic
     */
    @SuppressWarnings ("WeakerAccess")
    public void addTopic(
            TopicNode topic
    ) {
        rootCompetenceNode.addTopics(topic);
        super.addEdge(rootVertex, new Vertex<>(topic));
    }
    
    /**
     * Add subtopic boolean.
     *
     * @param parent   the parent
     * @param subtopic the subtopic
     * @return the boolean
     */
    @SuppressWarnings ({"WeakerAccess", "UnusedReturnValue"})
    public boolean addSubtopic(
            TopicNode parent,
            SubtopicNode subtopic
    ) {
        parent.addSubtopics(subtopic);
        return this.addEdgeIfParentExists(new Vertex<>(parent), new Vertex<>(subtopic));
    }
    
    /**
     * Add test boolean.
     *
     * @param parent the parent
     * @param node   the node
     * @return the boolean
     */
    @SuppressWarnings ({"WeakerAccess", "UnusedReturnValue"})
    public boolean addTest(
            SubtopicNode parent,
            TestNode node
    ) {
        parent.addTests(node);
        return this.addEdgeIfParentExists(new Vertex<>(parent), new Vertex<>(node));
    }
    
    /**
     * Add question boolean.
     *
     * @param parent the parent
     * @param node   the node
     * @return the boolean
     */
    @SuppressWarnings ({"WeakerAccess", "UnusedReturnValue"})
    public boolean addQuestion(
            TestNode parent,
            QuestionNode node
    ) {
        parent.addQuestions(node);
        return this.addEdgeIfParentExists(new Vertex<>(parent), new Vertex<>(node));
    }
}
