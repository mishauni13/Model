package model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import nodes.Node;
import nodes.QuestionNode;
import nodes.SubtopicNode;
import nodes.TestNode;
import nodes.TopicNode;

/**
 * Class represents student.
 */
public class Student {
    
    /**
     * Threshold for known level.
     */
    public static final Float KNOWN_THRESHOLD = 0.4f;
    
    /**
     * Student name.
     */
    private final String name;
    
    /**
     * Group name.
     */
    private final String group;
    
    /**
     * Student activity dates.
     */
    private List<Date> activityDates = new ArrayList<>();
    
    /**
     * Student courses.
     */
    private List<Course> courses = new ArrayList<>();
    
    /**
     * Student grades.
     */
    private List<Vector<Double>> grades = new ArrayList<>();
    
    /**
     * Student errors.
     */
    private List<Vector<Double>> errors = new ArrayList<>();
    
    /**
     * Instantiates a new Student.
     *
     * @param name  the name
     * @param group the group
     */
    public Student(
            String name,
            String group
    ) {
        this.name = name;
        this.group = group;
    }
    
    /**
     * Instantiates a new Student.
     *
     * @param name    the name
     * @param group   the group
     * @param courses the courses
     */
    public Student(
            String name,
            String group,
            List<Course> courses
    ) {
        this.name = name;
        this.group = group;
        this.courses = courses;
    }
    
    /**
     * Instantiates a new Student.
     *
     * @param name    the name
     * @param group   the group
     * @param courses the courses
     */
    public Student(
            String name,
            String group,
            Course... courses
    ) {
        this.name = name;
        this.group = group;
        this.courses = Arrays.asList(courses);
    }
    
    public List<QuestionNode> getRecommendations(TopicNode topicNode) {
        List<QuestionNode> recommendations = new ArrayList<>();
        
        List<QuestionNode> questionNodes = new ArrayList<>();
        for (SubtopicNode subtopicNode :
                topicNode.getChildNodes()) {
            for (TestNode testNode :
                    subtopicNode.getChildNodes()) {
                questionNodes.addAll(testNode.getChildNodes());
            }
        }
        
        int r = (int) (Math.random() * ((questionNodes.size() - 1) + 1));
        
        if (topicNode.getValue1() < 0.5f) {
            recommendations.add(questionNodes.get(r));
        }
        if (topicNode.getValue2() < 0.4f) {
            Float min = 1f;
            int it = 0;
            for (int i = 0; i < questionNodes.size(); i++) {
                QuestionNode n = questionNodes.get(i);
                if (n.getValue2() < min) {
                    min = n.getValue2();
                    it = i;
                }
            }
            recommendations.add(questionNodes.get(it));
        }
    
        r = (int) (Math.random() * ((questionNodes.size() - 1) + 1));
        
        if (topicNode.getValue3() > 0) {
            recommendations.add(questionNodes.get(r));
        }
        
        return recommendations;
    }
    
    /**
     * Adds course.
     *
     * @param course course to add.
     */
    public void addCourse(Course course) {
        this.courses.add(course);
    }
}
