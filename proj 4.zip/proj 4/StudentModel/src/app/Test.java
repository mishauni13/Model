package app;

import java.util.ArrayList;

import model.Course;
import model.CourseGraph;
import model.Edge;
import model.Graph;
import model.Student;
import model.Vertex;
import nodes.CompetenceNode;
import nodes.QuestionNode;
import nodes.SubtopicNode;
import nodes.TestNode;
import nodes.TopicNode;
import util.GraphUtils;

class Test {
    
    public static void main(String[] args) {
        doStudentModelTest();
    }
    
    private static void doStudentModelTest() {
        //IMG 19 example
        //Questions
        QuestionNode q1 = new QuestionNode("Question 1", "Q1",
                                           new QuestionNode.Answers(new ArrayList<>(), " Right!")
        );
        QuestionNode q2 = new QuestionNode("Question 2", "Q2",
                                           new QuestionNode.Answers(new ArrayList<>(), " Right!")
        );
        QuestionNode q3 = new QuestionNode("Question 3", "Q3",
                                           new QuestionNode.Answers(new ArrayList<>(), " Right!")
        );
        QuestionNode q4 = new QuestionNode("Question 4", "Q4",
                                           new QuestionNode.Answers(new ArrayList<>(), " Right!")
        );
        
        //Set questions value1
        q1.setValue(.2f, .3f, .5f);
        q2.setValue(.1f, .4f, .5f);
        q3.setValue(.0f, .5f, .5f);
        q4.setValue(.2f, .6f, .2f);
        
        //Tests
        TestNode test1 = new TestNode(
                "First test",
                q1, q2, q3, q4
        );
        TestNode test2 = new TestNode(
                "Second test",
                q2, q3, q4
        );
        
        //Creating student
        Student student = new Student("Dmitry Vasyliev", "A1");
        Course course = new Course(
                "Java programming course", "Course about Java advanced topics.");
    
        TopicNode topic = new TopicNode(
                "C10_Equivalence",
                new SubtopicNode(
                        "C10_Equivalence_S",
                        test1,
                        test2
                )
        );
        CompetenceNode root = new CompetenceNode(
                "...",
                topic
        );
        course.setCourseGraph(new CourseGraph(
                root
        ));
        
        //Adding weight to test1-q1
        course.getCourseGraph().getEdgeBetweenValues(test1, q1).addWeight(0.5f);
        student.addCourse(course);
        
        //Test results
        System.out.println("\n" + "Without connection weights:");
        System.out.println("First test \"Known\" value: " +
                           course.getCourseGraph().findVertex(test1).getStoredObject().getValue1() + ", " +
                           course.getCourseGraph().findVertex(test1).getStoredObject().getValue2() + ", " +
                           course.getCourseGraph().findVertex(test1).getStoredObject().getValue3()
        );
        System.out.println("Second test \"Known\" value: " +
                           course.getCourseGraph().findVertex(test2).getStoredObject().getValue1() + ", " +
                           course.getCourseGraph().findVertex(test2).getStoredObject().getValue2() + ", " +
                           course.getCourseGraph().findVertex(test2).getStoredObject().getValue3()
        );
        System.out.println("Competence \"Known\" value: " +
                           course.getCourseGraph().getRootVertex().getStoredObject().getValue1() + ", " +
                           course.getCourseGraph().getRootVertex().getStoredObject().getValue2() + ", " +
                           course.getCourseGraph().getRootVertex().getStoredObject().getValue3()
        );
        
        System.out.println("\n" + "With connection weights:");
        System.out.println("First test \"Known\" value: " +
                           course.getCourseGraph().calculateVertexProbability(test1)[0] + ", " +
                           course.getCourseGraph().calculateVertexProbability(test1)[1] + ", " +
                           course.getCourseGraph().calculateVertexProbability(test1)[2]
        );
        System.out.println("Second test \"Known\" value: " +
                           course.getCourseGraph().calculateVertexProbability(test2)[0] + ", " +
                           course.getCourseGraph().calculateVertexProbability(test2)[1] + ", " +
                           course.getCourseGraph().calculateVertexProbability(test2)[2]
        );
        System.out.println("Competence \"Known\" value: " +
                           course.getCourseGraph().calculateVertexProbability(root)[0] + ", " +
                           course.getCourseGraph().calculateVertexProbability(root)[1] + ", " +
                           course.getCourseGraph().calculateVertexProbability(root)[2]
        );
    
        System.out.println("\n");
        
        System.out.println(student.getRecommendations(topic));
    }
    
    private static void doBaseGraphModelTest() {
        int rootValue = 0;
        
        Graph<Integer> graph = Graph.createGraphFromRootVertexRelations(
                new Vertex<>(
                        rootValue,
                        new Edge<>(
                                new Vertex<>(
                                        rootValue
                                ),
                                new Vertex<>(
                                        2
                                ),
                                true
                        ),
                        new Edge<>(
                                new Vertex<>(
                                        rootValue
                                ),
                                new Vertex<>(
                                        3
                                ),
                                true
                        )
                )
        );
        
        GraphUtils.printGraph(graph);
    }
}
